class BusinessDailyAnalytics {
  const BusinessDailyAnalytics({
    this.views = 0,
    this.likes = 0,
    this.shares = 0,
    this.saves = 0,
  });

  final int views;
  final int likes;
  final int shares;
  final int saves;

  factory BusinessDailyAnalytics.fromJson(Map<String, Object?> data) =>
      BusinessDailyAnalytics(
        views: (data['views'] as num?)?.toInt() ?? 0,
        likes: (data['likes'] as num?)?.toInt() ?? 0,
        shares: (data['shares'] as num?)?.toInt() ?? 0,
        saves: (data['saves'] as num?)?.toInt() ?? 0,
      );

  BusinessDailyAnalytics operator +(BusinessDailyAnalytics other) =>
      BusinessDailyAnalytics(
        views: views + other.views,
        likes: likes + other.likes,
        shares: shares + other.shares,
        saves: saves + other.saves,
      );
}
