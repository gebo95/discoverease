import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../models/listing.dart';
import '../../../repositories/listing_repository.dart';
import '../../../repositories/saved_repository.dart';
import '../../../repositories/destination_repository.dart';
import '../../../shared/theme/de_colors.dart';
import '../../../shared/theme/de_radius.dart';
import '../../../shared/theme/de_spacing.dart';
import '../../listing/pages/listing_detail_page.dart';
import '../utils/saved_group_builder.dart';

class SavedPage extends StatelessWidget {
  const SavedPage({super.key});

  @override
  Widget build(BuildContext context) {
    final savedItems = context.watch<SavedRepository>().getAllSaved();
    final listingRepository = context.watch<ListingRepository>();
    final destinationRepository = context.watch<DestinationRepository>();
    final groups = SavedGroupBuilder.build(
      saved: savedItems,
      listings: listingRepository,
      destinations: destinationRepository,
    );
    final savedCount = groups.fold<int>(0, (total, group) => total + group.count);

    return Scaffold(
      backgroundColor: DEColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(DESpacing.md),
          children: [
            const SizedBox(height: 12),
            const Text(
              'Saved',
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.w900,
                color: DEColors.textPrimary,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Keep the experiences you want to come back to.',
              style: TextStyle(fontSize: 15, color: DEColors.textSecondary),
            ),
            const SizedBox(height: 24),
            Text(
              'Experiences · $savedCount',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: DESpacing.md),
            if (groups.isEmpty)
              const _EmptySavedState()
            else
              ...groups.map(
                (group) => Padding(
                  padding: const EdgeInsets.only(bottom: DESpacing.sm),
                  child: _SavedCountryTile(
                    group: group,
                    onListingTap: (listing) => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ListingDetailPage(listing: listing),
                      ),
                    ),
                    onRemove: (listing) => context
                        .read<SavedRepository>()
                        .remove(listing.id),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _SavedCountryTile extends StatelessWidget {
  final SavedCountryGroup group;
  final ValueChanged<Listing> onListingTap;
  final ValueChanged<Listing> onRemove;

  const _SavedCountryTile({
    required this.group,
    required this.onListingTap,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: DEColors.surface,
      borderRadius: BorderRadius.circular(DERadius.extraLarge),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        key: PageStorageKey('saved-country:${group.name}'),
        initiallyExpanded: false,
        tilePadding: const EdgeInsets.symmetric(horizontal: DESpacing.md),
        title: Text(group.name, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('${group.count} saved'),
        children: group.areas
            .map(
              (area) => _SavedAreaTile(
                country: group.name,
                area: area,
                onListingTap: onListingTap,
                onRemove: onRemove,
              ),
            )
            .toList(growable: false),
      ),
    );
  }
}

class _SavedAreaTile extends StatelessWidget {
  final String country;
  final SavedAreaGroup area;
  final ValueChanged<Listing> onListingTap;
  final ValueChanged<Listing> onRemove;

  const _SavedAreaTile({
    required this.country,
    required this.area,
    required this.onListingTap,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      key: PageStorageKey('saved-area:$country:${area.name}'),
      initiallyExpanded: false,
      tilePadding: const EdgeInsets.only(left: DESpacing.lg, right: DESpacing.md),
      title: Text(area.name, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('${area.count} saved'),
      children: area.categories
          .map(
            (category) => _SavedCategoryTile(
              country: country,
              area: area.name,
              category: category,
              onListingTap: onListingTap,
              onRemove: onRemove,
            ),
          )
          .toList(growable: false),
    );
  }
}

class _SavedCategoryTile extends StatelessWidget {
  final String country;
  final String area;
  final SavedCategoryGroup category;
  final ValueChanged<Listing> onListingTap;
  final ValueChanged<Listing> onRemove;

  const _SavedCategoryTile({
    required this.country,
    required this.area,
    required this.category,
    required this.onListingTap,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      key: PageStorageKey('saved-category:$country:$area:${category.name}'),
      initiallyExpanded: false,
      tilePadding: const EdgeInsets.only(left: DESpacing.xl, right: DESpacing.md),
      title: Text(category.name, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text('${category.listings.length} saved'),
      childrenPadding: const EdgeInsets.symmetric(horizontal: DESpacing.md),
      children: category.listings
          .map(
            (listing) => _SavedListingCard(
              listing: listing,
              onTap: () => onListingTap(listing),
              onRemove: () => onRemove(listing),
            ),
          )
          .toList(growable: false),
    );
  }
}

class _SavedListingCard extends StatelessWidget {
  final Listing listing;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  const _SavedListingCard({
    required this.listing,
    required this.onTap,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: DESpacing.md),
      decoration: BoxDecoration(
        color: DEColors.surface,
        borderRadius: BorderRadius.circular(DERadius.extraLarge),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(DERadius.extraLarge),
        child: Padding(
          padding: const EdgeInsets.all(DESpacing.sm),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(DERadius.large),
                child: Image.network(
                  listing.imageUrl,
                  width: 82,
                  height: 82,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => const SizedBox(
                    width: 82,
                    height: 82,
                    child: ColoredBox(
                      color: DEColors.border,
                      child: Icon(Icons.image_not_supported_outlined),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: DESpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      listing.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${listing.location} · ${listing.price}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: DEColors.textSecondary),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Remove from saved',
                onPressed: onRemove,
                icon: const Icon(Icons.favorite_rounded, color: Colors.redAccent),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptySavedState extends StatelessWidget {
  const _EmptySavedState();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(DESpacing.lg),
      decoration: BoxDecoration(
        color: DEColors.surface,
        borderRadius: BorderRadius.circular(DERadius.extraLarge),
      ),
      child: const Column(
        children: [
          Icon(Icons.bookmark_border_rounded, size: 40, color: DEColors.primary),
          SizedBox(height: DESpacing.sm),
          Text('No saved experiences yet', style: TextStyle(fontWeight: FontWeight.w900)),
          SizedBox(height: 4),
          Text(
            'Save a place from its detail page and it will appear here.',
            textAlign: TextAlign.center,
            style: TextStyle(color: DEColors.textSecondary),
          ),
        ],
      ),
    );
  }
}
