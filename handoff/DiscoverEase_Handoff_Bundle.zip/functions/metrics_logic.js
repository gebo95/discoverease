const { createHash } = require('node:crypto');

function utcDay(date) {
  return date.toISOString().slice(0, 10).replaceAll('-', '');
}

function utcMinute(date) {
  return date.toISOString().slice(0, 16).replaceAll(/[-:T]/g, '');
}

function digest(value) {
  return createHash('sha256').update(value).digest('hex');
}

function transitionDelta(beforeExists, afterExists) {
  if (!beforeExists && afterExists) return 1;
  if (beforeExists && !afterExists) return -1;
  return 0;
}

function publishedBusinessId(listing, business) {
  if (listing?.status !== 'published' || business?.status !== 'published') {
    return null;
  }
  const businessId = listing.businessId;
  return typeof businessId === 'string' && businessId.length > 0
    ? businessId
    : null;
}

module.exports = {
  utcDay,
  utcMinute,
  digest,
  transitionDelta,
  publishedBusinessId,
};
